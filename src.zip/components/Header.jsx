import { Link } from "react-router-dom";
export default function Header() {

    return (
        <header>
            <nav style={{display: "flex", gap: "70px", justifyContent: "center", padding: "1rem"}}>
                <p  >
                    <Link to="" className="nav">Home</Link>
                </p>
                <p className="nav">
                    <Link to="first" className="nav">Spil anbefaler</Link>
                </p>
                <p className="nav" >
                    <Link to="second" className="nav">Energidrik Udvægler</Link>
                </p>
            </nav>
        </header>
    )
}