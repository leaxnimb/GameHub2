export default function Home() {
    return (
        <div className="forsideContainer">
            <h2 className="forsideH2">Gamehub</h2>
            <p className="punchline">Den Ultimative Gaming-Oplevelse Venter Derude!</p>
        </div>
    )

}